# Stick Studio

Telefonda ishlaydigan "tayoqcha odam" tushuntiruvchi video yaratuvchi ilova (Zenn kanali uslubida). Ssenariyni telefon ichidagi AI modeli yozadi, ovozni telefonning o'z ovozi o'qiydi, video ham telefonda chiziladi.

## Nima qiladi

1. Birinchi ishga tushganda **o'zi bitta personaj yaratadi** (soch, ko'z, aksessuar, ranglar) va saqlab qo'yadi. Hamma videolarda shu qahramon qatnashadi.
2. **AI model** (Gemma 4 E2B, Apache-2.0 litsenziya, token yoki akkaunt kerak emas) bir marta `2,6 GB` yuklab olinadi. Shundan keyin **internetsiz, istalgan mavzuda** ssenariy yozadi: hook, faktlar, burilish, xulosa.
3. Model yuklanmagan bo'lsa yoki o'z faktlaringizni yozsangiz, tayyor shablon dvigateli ishlaydi (5 ta tayyor mavzu, ingliz va o'zbek tilida).
4. Har bir sahna matnini tahrirlash mumkin. "Videoni yaratish" bosilganda ovoz yaratiladi, kadrlar chiziladi va MP4 galereyaga saqlanadi.

## Talablar (telefon)

- Android 11 yoki yangi, 64 bitli protsessor (deyarli hamma yangi telefon).
- AI uchun taxminan 6 GB RAM va 3 GB bo'sh joy tavsiya etiladi. Telefon kuchsiz bo'lsa, AI'siz shablon rejimi ishlayveradi.
- Modelni yuklab olish uchun internet (bir marta). Ilovaning qolgan qismi internetsiz.

## APK olish

### Variant A: faqat telefondan (GitHub orqali)
1. Shu papkani GitHub'da yangi repositoriyga yuklang.
2. Repositoriyda **Actions** > **Build APK** > **Run workflow**.
3. 10-15 daqiqadan keyin tugagan ishni oching, pastdagi **Artifacts** ichidan `stick-studio-apk` ni yuklab oling, ichidan `app-release.apk` ni o'rnating.

### Variant B: kompyuterda
```
python3 tools/setup_android.py
flutter pub get
flutter build apk --release --target-platform android-arm64
```
APK: `build/app/outputs/flutter-apk/app-release.apk`

`tools/setup_android.py` Android papkasini yaratadi va kerakli ruxsatlarni (internet, galereya), minSdk 30 va ovoz sozlamalarini o'zi qo'shadi.

## Muhim cheklovlar (halol)

- **Kod hali kompilyatsiya qilinmagan.** Yozilgan muhitda Flutter yo'q edi. AI qismi `flutter_edge_ai` paketining rasmiy hujjatlariga qarab yozilgan, lekin ishga tushirib sinalmagan. Birinchi yig'ishda kichik xatolar chiqishi mumkin: xato matnini yuboring.
- **O'zbekcha sifat noma'lum.** Gemma 4 ko'p tilli, lekin o'zbek tilini rasman tasdiqlangan deb bo'lmaydi. Birinchi o'zbekcha ssenariyni o'zingiz o'qib ko'ring. Ingliz tilida sifat ancha ishonchli.
- **AI xato qilishi mumkin.** Kichik model fakt, son yoki sanani adashtirishi mumkin. Videoni chiqarishdan oldin sahna matnlarini o'qib chiqing, kerakli joyini tahrirlang.
- **Yozish tezligi** telefonga bog'liq: 6 ta fakt uchun odatda 1-3 daqiqa.
- **O'zbek ovozi** hamma telefonda yo'q. Topilmasa: Sozlamalar > Til > Matndan ovozga bo'limidan Google ovozini yuklab oling.
- Model yuklangandan keyin ilova qayta ochilganda "yuklanmagan" desa, "Modelni yuklab olish" ni yana bosing (fayl bor bo'lsa, qayta yuklamasligi kerak).
- Video chizilayotganda ilovani yopmang va ekranni o'chirmang. 1280x720, 12 kadr/s, 2 daqiqalik video uchun taxminan 2-5 daqiqa ketadi.

## Tuzilma

| Fayl | Vazifasi |
|---|---|
| `lib/llm_service.dart` | Telefon ichidagi model: yuklash, o'chirish, matn yozish |
| `lib/script_engine.dart` | Shablon dvigateli, AI dvigateli, javobni tahlil qilish |
| `lib/character.dart` | Personajni yaratish, saqlash va chizish |
| `lib/scene_painter.dart` | Fonlar, rekvizitlar, sarlavha, subtitrlar |
| `lib/tts_service.dart`, `lib/wav.dart` | Ovoz yaratish va WAV o'qish |
| `lib/video_exporter.dart` | Kadrlar + ovoz > MP4 |
| `lib/home_page.dart` | Asosiy ekran |

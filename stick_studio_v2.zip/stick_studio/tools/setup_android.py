#!/usr/bin/env python3
"""Generate the Android platform folder with `flutter create` and patch it for Stick Studio.

Run once from anywhere:  python3 tools/setup_android.py
Safe to run again: the patches are idempotent.
"""
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent.parent
MARKER = "STICK_STUDIO_PATCHED"


def snapshot():
    """Remember our own sources so `flutter create` can never overwrite them."""
    saved = {}
    for name in ("pubspec.yaml", "analysis_options.yaml"):
        p = ROOT / name
        if p.exists():
            saved[p] = p.read_bytes()
    for p in (ROOT / "lib").rglob("*"):
        if p.is_file():
            saved[p] = p.read_bytes()
    return saved


def patch_manifest():
    path = ROOT / "android/app/src/main/AndroidManifest.xml"
    text = path.read_text(encoding="utf-8")

    # Release builds need INTERNET to download the AI model once.
    if "android.permission.INTERNET" not in text:
        text = text.replace(
            "<application",
            '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
            1,
        )
        path.write_text(text, encoding="utf-8")
        print("INTERNET permission added")

    if MARKER in text:
        print("Manifest already patched")
        return

    perms = (
        '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" '
        'android:maxSdkVersion="29"/>\n    '
    )
    tts_intent = (
        "\n        <intent>\n"
        '            <action android:name="android.intent.action.TTS_SERVICE"/>\n'
        "        </intent>\n    "
    )

    text = re.sub(r'android:label="[^"]*"', 'android:label="Stick Studio"', text, count=1)

    if "<queries>" in text:
        text = text.replace("<queries>", "<queries>" + tts_intent, 1)
        queries_block = ""
    else:
        queries_block = "<queries>" + tts_intent + "</queries>\n    "

    text = text.replace(
        "<application",
        "<!-- " + MARKER + " -->\n    " + perms + queries_block + "<application\n"
        '        android:requestLegacyExternalStorage="true"',
        1,
    )
    path.write_text(text, encoding="utf-8")
    print("Manifest patched")


def patch_gradle():
    for name in ("android/app/build.gradle", "android/app/build.gradle.kts"):
        path = ROOT / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        # The on-device AI engine needs Android 11 (API 30) or newer.
        new = re.sub(r"minSdk\s*=\s*(flutter\.minSdkVersion|\d+)", "minSdk = 30", text)
        new = re.sub(r"minSdkVersion\s+(flutter\.minSdkVersion|\d+)", "minSdkVersion 30", new)
        if new != text:
            path.write_text(new, encoding="utf-8")
            print("minSdk set to 30 in", name)


def main():
    saved = snapshot()
    if not (ROOT / "android").exists():
        subprocess.check_call(
            [
                "flutter", "create", "--platforms=android",
                "--project-name", "stick_studio",
                "--org", "uz.stickstudio", ".",
            ],
            cwd=ROOT,
        )
    for p, data in saved.items():
        p.write_bytes(data)

    default_test = ROOT / "test" / "widget_test.dart"
    if default_test.exists():
        default_test.unlink()

    patch_manifest()
    patch_gradle()
    print("Done. Now run: flutter pub get && flutter build apk --release --target-platform android-arm64")


if __name__ == "__main__":
    main()

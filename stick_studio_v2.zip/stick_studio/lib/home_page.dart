import 'package:flutter/material.dart';
import 'package:gal/gal.dart';

import 'character.dart';
import 'llm_service.dart';
import 'models.dart';
import 'result_page.dart';
import 'scene_preview.dart';
import 'script_engine.dart';
import 'tts_service.dart';
import 'video_exporter.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScriptEngine _template = TemplateScriptEngine();
  final ScriptEngine _ai = LlmScriptEngine();
  final TtsService _tts = TtsService();
  final TextEditingController _topicCtrl = TextEditingController();
  final TextEditingController _factsCtrl = TextEditingController();

  CharacterSpec? _character;
  String _lang = 'en';
  String? _topicId;
  List<VideoScene> _scenes = [];
  List<TextEditingController> _narration = [];
  int _selected = 0;

  bool _useAi = false;
  int _factCount = 6;
  bool _generating = false;
  int _written = 0;
  bool _downloading = false;
  int _percent = 0;
  String? _downloadError;

  @override
  void initState() {
    super.initState();
    _loadCharacter();
  }

  @override
  void dispose() {
    _topicCtrl.dispose();
    _factsCtrl.dispose();
    for (final c in _narration) {
      c.dispose();
    }
    _tts.stop();
    super.dispose();
  }

  Future<void> _loadCharacter() async {
    CharacterSpec c;
    try {
      c = await CharacterStore.loadOrCreate();
    } catch (e) {
      CharacterStore.lastError = e.toString();
      c = CharacterSpec.fromSeed(DateTime.now().millisecondsSinceEpoch & 0x3fffffff);
    }
    if (!mounted) return;
    setState(() => _character = c);
  }

  Future<void> _newCharacter() async {
    final c = await CharacterStore.regenerate();
    if (!mounted) return;
    setState(() => _character = c);
  }

  void _snack(String text) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  void _setScenes(List<VideoScene> scenes) {
    for (final c in _narration) {
      c.dispose();
    }
    _scenes = scenes;
    _narration = [for (final s in scenes) TextEditingController(text: s.narration)];
    _selected = 0;
  }

  Future<void> _generate() async {
    if (_generating) return;
    final facts = _factsCtrl.text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    // Facts typed by the user always win: they are used as they are.
    final useAi = _useAi && facts.isEmpty && LlmService.isInstalled;

    setState(() {
      _generating = true;
      _written = 0;
    });
    try {
      final engine = useAi ? _ai : _template;
      final scenes = await engine.generate(
        ScriptRequest(
          topic: _topicCtrl.text.trim(),
          lang: _lang,
          facts: facts,
          topicId: facts.isEmpty ? _topicId : null,
          factCount: _factCount,
        ),
        onProgress: (n) {
          if (mounted) setState(() => _written = n);
        },
      );
      if (!mounted) return;
      setState(() => _setScenes(scenes));
    } on ScriptException catch (e) {
      _snack(e.message);
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _downloadModel() async {
    setState(() {
      _downloading = true;
      _percent = 0;
      _downloadError = null;
    });
    try {
      await LlmService.install((p) {
        if (mounted) setState(() => _percent = p);
      });
      if (mounted) setState(() => _useAi = true);
    } catch (e) {
      if (mounted) setState(() => _downloadError = e.toString());
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  Future<void> _deleteModel() async {
    try {
      await LlmService.uninstall();
    } catch (e) {
      _snack("O'chirib bo'lmadi: $e");
    }
    if (mounted) setState(() => _useAi = false);
  }

  Future<void> _listen() async {
    if (_scenes.isEmpty) return;
    final ok = await _tts.prepare(_lang);
    if (!ok) {
      _snack("Telefonda bu til uchun ovoz o'rnatilmagan.");
      return;
    }
    await _tts.stop();
    await _tts.speak(_narration[_selected].text);
  }

  Future<void> _export() async {
    final character = _character;
    if (_scenes.isEmpty || character == null) return;

    for (var i = 0; i < _scenes.length; i++) {
      _scenes[i].narration = _narration[i].text.trim();
      _scenes[i].reestimate();
    }

    final progress = ValueNotifier<double>(0);
    final status = ValueNotifier<String>('Tayyorlanmoqda...');
    var cancelled = false;

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: const Text('Video yaratilmoqda'),
          content: ValueListenableBuilder<double>(
            valueListenable: progress,
            builder: (_, p, __) => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                LinearProgressIndicator(value: p),
                const SizedBox(height: 12),
                ValueListenableBuilder<String>(
                  valueListenable: status,
                  builder: (_, s, __) => Text(s),
                ),
                const SizedBox(height: 8),
                const Text("Ilovani yopmang va ekranni o'chirmang."),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => cancelled = true,
              child: const Text('Bekor qilish'),
            ),
          ],
        ),
      ),
    );

    String? path;
    String? error;
    var note = '';
    try {
      path = await VideoExporter().export(
        scenes: _scenes,
        character: character,
        lang: _lang,
        onProgress: (p, s) {
          progress.value = p;
          status.value = s;
        },
        isCancelled: () => cancelled,
      );
      try {
        if (!await Gal.hasAccess()) {
          await Gal.requestAccess();
        }
        await Gal.putVideo(path);
        note = 'Video galereyaga saqlandi.';
      } catch (e) {
        note = "Galereyaga saqlab bo'lmadi ($e). Fayl pastdagi joyda turibdi.";
      }
    } on ExportCancelled {
      error = 'Bekor qilindi.';
    } catch (e) {
      error = e.toString();
    }

    if (!mounted) return;
    Navigator.of(context, rootNavigator: true).pop();
    progress.dispose();
    status.dispose();

    if (error != null) {
      _snack(error);
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ResultPage(path: path!, note: note),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final character = _character;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Stick Studio')),
      body: character == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _characterCard(character, theme),
                const SizedBox(height: 16),
                _aiCard(theme),
                const SizedBox(height: 16),
                _inputCard(theme),
                if (_scenes.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  _scenesSection(character, theme),
                ],
                const SizedBox(height: 32),
              ],
            ),
    );
  }

  Widget _characterCard(CharacterSpec character, ThemeData theme) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            SizedBox(
              width: 110,
              height: 130,
              child: CharacterPreview(character: character),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Sizning qahramoningiz', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 4),
                  const Text(
                    "Ilova uni o'zi yaratdi va eslab qoladi. Barcha videolarda shu personaj qatnashadi.",
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton(
                    onPressed: _newCharacter,
                    child: const Text('Boshqa personaj yaratish'),
                  ),
                  if (CharacterStore.lastError != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        "Personaj saqlanmadi: ${CharacterStore.lastError}",
                        style: TextStyle(color: theme.colorScheme.error, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _aiCard(ThemeData theme) {
    final installed = LlmService.isInstalled;
    final minutes = (_factCount * 0.28 + 0.6).toStringAsFixed(1);

    final List<Widget> content;
    if (!LlmService.isSupported) {
      content = [
        Text(
          "Bu telefonda AI model ishlamaydi (Android 11 va 64 bitli protsessor kerak). "
          "${LlmService.initError ?? ''}",
        ),
      ];
    } else if (_downloading) {
      content = [
        LinearProgressIndicator(value: _percent / 100),
        const SizedBox(height: 8),
        Text('Yuklanmoqda: $_percent%'),
        const Text("Ilovani yopmang. Bu bir marta qilinadi."),
      ];
    } else if (!installed) {
      content = [
        Text(
          "Telefon ichida ishlaydigan Gemma 4 modeli. Bir marta ${LlmService.sizeLabel} "
          "yuklab olinadi (Wi-Fi tavsiya), keyin internetsiz istalgan mavzuda ssenariy yozadi.",
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: _downloadModel,
          icon: const Icon(Icons.download),
          label: const Text('Modelni yuklab olish'),
        ),
      ];
    } else {
      content = [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: _useAi,
          onChanged: (v) => setState(() => _useAi = v),
          title: const Text('AI bilan ssenariy yozish'),
          subtitle: const Text("O'z faktlaringizni yozsangiz, AI ishlatilmaydi."),
        ),
        if (_useAi) ...[
          Text('Fakt soni: $_factCount (video taxminan $minutes daqiqa)'),
          Slider(
            value: _factCount.toDouble(),
            min: 3,
            max: 12,
            divisions: 9,
            label: '$_factCount',
            onChanged: (v) => setState(() => _factCount = v.round()),
          ),
        ],
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: _deleteModel,
            icon: const Icon(Icons.delete_outline),
            label: const Text("Modelni o'chirish (joy bo'shatish)"),
          ),
        ),
      ];
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('AI ssenariy yozuvchi', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            ...content,
            if (_downloadError != null) ...[
              const SizedBox(height: 8),
              Text(
                "Yuklab bo'lmadi: $_downloadError",
                style: TextStyle(color: theme.colorScheme.error),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _inputCard(ThemeData theme) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Ovoz tili', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'en', label: Text('English')),
                ButtonSegment(value: 'uz', label: Text("O'zbek")),
              ],
              selected: {_lang},
              onSelectionChanged: (s) {
                setState(() {
                  _lang = s.first;
                  if (_topicId != null) {
                    _topicCtrl.text = kTopics
                        .firstWhere((t) => t.id == _topicId)
                        .titleFor(_lang);
                  }
                });
              },
            ),
            const SizedBox(height: 16),
            Text('Tayyor mavzular', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final t in kTopics)
                  ChoiceChip(
                    label: Text(t.titleFor(_lang)),
                    selected: _topicId == t.id,
                    onSelected: (_) => setState(() {
                      _topicId = t.id;
                      _topicCtrl.text = t.titleFor(_lang);
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _topicCtrl,
              decoration: const InputDecoration(
                labelText: 'Mavzu nomi',
                helperText: 'AI yoqilgan bo\'lsa, istalgan mavzuni yozing.',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) {
                final id = _topicId;
                if (id == null) return;
                final title = kTopics.firstWhere((t) => t.id == id).titleFor(_lang);
                if (v != title) setState(() => _topicId = null);
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _factsCtrl,
              minLines: 3,
              maxLines: 8,
              decoration: const InputDecoration(
                labelText: "O'z faktlaringiz (ixtiyoriy)",
                helperText:
                    "Har qatorga bitta fakt. Bo'sh qoldirsangiz, tayyor mavzu ishlatiladi.",
                helperMaxLines: 2,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _generating ? null : _generate,
                icon: const Icon(Icons.auto_awesome),
                label: Text(_generating ? 'Yozilmoqda...' : 'Ssenariy yaratish'),
              ),
            ),
            if (_generating && _useAi) ...[
              const SizedBox(height: 12),
              const LinearProgressIndicator(),
              const SizedBox(height: 4),
              Text('Model yozmoqda... $_written belgi'),
            ],
          ],
        ),
      ),
    );
  }

  Widget _scenesSection(CharacterSpec character, ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Ssenariy (${_scenes.length} sahna)', style: theme.textTheme.titleMedium),
        const SizedBox(height: 8),
        ScenePreview(
          key: ValueKey(_selected),
          scene: _scenes[_selected],
          character: character,
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            OutlinedButton.icon(
              onPressed: _listen,
              icon: const Icon(Icons.volume_up),
              label: const Text('Ovozini eshitish'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        for (var i = 0; i < _scenes.length; i++)
          Card(
            color: i == _selected ? theme.colorScheme.primaryContainer : null,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    onPressed: () => setState(() => _selected = i),
                    icon: Icon(
                      i == _selected ? Icons.visibility : Icons.visibility_outlined,
                    ),
                    tooltip: "Ko'rish",
                  ),
                  Expanded(
                    child: TextField(
                      controller: _narration[i],
                      minLines: 1,
                      maxLines: 6,
                      onTap: () => setState(() => _selected = i),
                      onChanged: (v) {
                        _scenes[i].narration = v;
                        _scenes[i].reestimate();
                      },
                      decoration: InputDecoration(
                        labelText: 'Sahna ${i + 1}',
                        border: const OutlineInputBorder(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _export,
          icon: const Icon(Icons.movie_creation),
          label: const Text('Videoni yaratish'),
        ),
      ],
    );
  }
}

import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'character.dart';
import 'models.dart';
import 'scene_painter.dart';

/// Looping live preview of one scene (no sound).
class ScenePreview extends StatefulWidget {
  const ScenePreview({super.key, required this.scene, required this.character});

  final VideoScene scene;
  final CharacterSpec character;

  @override
  State<ScenePreview> createState() => _ScenePreviewState();
}

class _ScenePreviewState extends State<ScenePreview>
    with SingleTickerProviderStateMixin {
  static const double _loopSeconds = 20;

  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 20),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) {
            final dur = math.max(1.0, widget.scene.duration);
            final t = (_c.value * _loopSeconds) % dur;
            return CustomPaint(
              painter: ScenePainter(
                scene: widget.scene,
                t: t,
                character: widget.character,
              ),
              size: Size.infinite,
            );
          },
        ),
      ),
    );
  }
}

/// Small animated portrait of the hero.
class CharacterPreview extends StatefulWidget {
  const CharacterPreview({super.key, required this.character});

  final CharacterSpec character;

  @override
  State<CharacterPreview> createState() => _CharacterPreviewState();
}

class _CharacterPreviewState extends State<CharacterPreview>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 30),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => CustomPaint(
        painter: _CharacterOnlyPainter(widget.character, _c.value * 30),
        size: Size.infinite,
      ),
    );
  }
}

class _CharacterOnlyPainter extends CustomPainter {
  _CharacterOnlyPainter(this.character, this.t);

  final CharacterSpec character;
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(16)),
      Paint()..color = const Color(0xFFF0E2C0),
    );
    drawCharacter(
      canvas,
      character,
      feet: Offset(size.width / 2, size.height * 0.96),
      height: size.height * 1.1,
      t: t,
      emotion: Emotion.happy,
      pose: Pose.wave,
    );
  }

  @override
  bool shouldRepaint(_CharacterOnlyPainter old) =>
      old.t != t || old.character != character;
}

import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_quick_video_encoder/flutter_quick_video_encoder.dart';
import 'package:path_provider/path_provider.dart';

import 'character.dart';
import 'models.dart';
import 'scene_painter.dart';
import 'tts_service.dart';
import 'wav.dart';

class ExportCancelled implements Exception {}

class ExportException implements Exception {
  ExportException(this.message);
  final String message;

  @override
  String toString() => message;
}

typedef ProgressCallback = void Function(double progress, String status);

/// Renders every scene frame by frame with [ScenePainter], speaks the narration
/// with the phone's TTS engine, and muxes both into an MP4 using the phone's
/// hardware encoder. Nothing leaves the device.
class VideoExporter {
  static const int width = 1280;
  static const int height = 720;
  static const int fps = 12;

  Future<String> export({
    required List<VideoScene> scenes,
    required CharacterSpec character,
    required String lang,
    required ProgressCallback onProgress,
    required bool Function() isCancelled,
  }) async {
    if (scenes.isEmpty) throw ExportException('No scenes to render');

    final tts = TtsService();
    final ready = await tts.prepare(lang);
    if (!ready) {
      throw ExportException(lang == 'uz'
          ? "Telefoningizda o'zbek tilidagi ovoz topilmadi. Sozlamalar > Til > Matndan ovozga "
              "(Google TTS) bo'limidan ovozni yuklab oling yoki English tilini tanlang."
          : "No English voice found on this phone. Install it in Settings > Language > "
              "Text-to-speech output.");
    }

    final dir = await getTemporaryDirectory();

    // ---- 1. Voice for every scene
    final audios = <PcmAudio>[];
    for (var i = 0; i < scenes.length; i++) {
      if (isCancelled()) throw ExportCancelled();
      onProgress(0.02 + 0.18 * i / scenes.length,
          'Ovoz yaratilmoqda ${i + 1}/${scenes.length}');
      final wavPath = '${dir.path}/tts_$i.wav';
      await tts.synthesizeToWav(scenes[i].narration, wavPath);
      final bytes = await File(wavPath).readAsBytes();
      try {
        await File(wavPath).delete();
      } catch (_) {}
      audios.add(parseWav(bytes));
    }

    final rate = audios.first.sampleRate;
    final pcm = <Int16List>[
      for (final a in audios) resampleLinear(a.samples, a.sampleRate, rate),
    ];
    for (var i = 0; i < scenes.length; i++) {
      final speech = pcm[i].length / rate;
      scenes[i].speechDuration = speech;
      scenes[i].duration = math.max(2.5, speech + 0.5);
    }

    var totalFrames = 0;
    for (final s in scenes) {
      totalFrames += (s.duration * fps).round();
    }

    // ---- 2. Render frames and encode
    final out = '${dir.path}/stick_${DateTime.now().millisecondsSinceEpoch}.mp4';
    await FlutterQuickVideoEncoder.setup(
      width: width,
      height: height,
      fps: fps,
      videoBitrate: 2500000,
      profileLevel: ProfileLevel.any,
      audioChannels: 1,
      audioBitrate: 64000,
      sampleRate: rate,
      filepath: out,
    );

    var done = 0;
    try {
      for (var si = 0; si < scenes.length; si++) {
        final scene = scenes[si];
        final frames = (scene.duration * fps).round();
        final samplesTotal = (frames * rate / fps).round();

        final audio = Int16List(samplesTotal);
        final src = pcm[si];
        audio.setRange(0, math.min(src.length, samplesTotal), src);

        var audioPos = 0;
        for (var f = 0; f < frames; f++) {
          if (isCancelled()) throw ExportCancelled();

          final painter = ScenePainter(
            scene: scene,
            t: f / fps,
            character: character,
          );
          final rgba = await _renderFrame(painter);
          await FlutterQuickVideoEncoder.appendVideoFrame(rgba);

          final end = ((f + 1) * samplesTotal / frames).round();
          if (end > audioPos) {
            final view = Uint8List.view(
              audio.buffer,
              audio.offsetInBytes + audioPos * 2,
              (end - audioPos) * 2,
            );
            await FlutterQuickVideoEncoder.appendAudioFrame(
                Uint8List.fromList(view));
            audioPos = end;
          }

          done++;
          if (done % 6 == 0 || done == totalFrames) {
            onProgress(0.2 + 0.78 * done / totalFrames,
                'Kadrlar: $done / $totalFrames');
          }
        }
      }
      await FlutterQuickVideoEncoder.finish();
    } catch (_) {
      try {
        await FlutterQuickVideoEncoder.finish();
      } catch (_) {}
      rethrow;
    }

    onProgress(1.0, 'Tayyor');
    return out;
  }

  Future<Uint8List> _renderFrame(ScenePainter painter) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(
      recorder,
      Rect.fromLTWH(0, 0, width.toDouble(), height.toDouble()),
    );
    painter.paint(canvas, Size(width.toDouble(), height.toDouble()));
    final picture = recorder.endRecording();
    final image = await picture.toImage(width, height);
    final data = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    image.dispose();
    picture.dispose();
    if (data == null) throw ExportException('Could not render a frame');
    return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
  }
}

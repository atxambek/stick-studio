import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

const Color _inkColor = Color(0xFF141414);

/// The one hero of every video. Everything about the look is derived from [seed],
/// so storing the seed is enough to get exactly the same character back.
class CharacterSpec {
  const CharacterSpec._({
    required this.seed,
    required this.hairStyle,
    required this.eyeStyle,
    required this.accessory,
    required this.headScale,
    required this.outfit,
    required this.hair,
    required this.accent,
  });

  final int seed;

  /// 0 none, 1 spiky, 2 bangs, 3 curly, 4 cap
  final int hairStyle;

  /// 0 dots, 1 ovals with pupils, 2 big shiny eyes
  final int eyeStyle;

  /// 0 none, 1 glasses, 2 scarf, 3 bow tie
  final int accessory;
  final double headScale;
  final Color outfit;
  final Color hair;
  final Color accent;

  static const List<Color> _outfits = [
    Color(0xFFD64545),
    Color(0xFF3B82C4),
    Color(0xFF3FA66B),
    Color(0xFFE0A526),
    Color(0xFF8E5BD0),
    Color(0xFFE6772E),
  ];
  static const List<Color> _hairs = [
    Color(0xFF1B1B1B),
    Color(0xFF5A3825),
    Color(0xFFB5651D),
    Color(0xFFC9A227),
    Color(0xFF6B6B6B),
  ];
  static const List<Color> _accents = [
    Color(0xFFE53935),
    Color(0xFF1E88E5),
    Color(0xFF43A047),
    Color(0xFFFFB300),
    Color(0xFF8E24AA),
  ];

  factory CharacterSpec.fromSeed(int seed) {
    final r = math.Random(seed);
    return CharacterSpec._(
      seed: seed,
      hairStyle: r.nextInt(5),
      eyeStyle: r.nextInt(3),
      accessory: r.nextInt(4),
      headScale: 1.0 + r.nextDouble() * 0.25,
      outfit: _outfits[r.nextInt(_outfits.length)],
      hair: _hairs[r.nextInt(_hairs.length)],
      accent: _accents[r.nextInt(_accents.length)],
    );
  }

  @override
  bool operator ==(Object other) => other is CharacterSpec && other.seed == seed;

  @override
  int get hashCode => seed;
}

/// Keeps the hero between app launches.
class CharacterStore {
  static const String _key = 'character_seed';

  /// Set when the hero could not be saved or loaded. The app still works,
  /// but the character will then be different after a restart.
  static String? lastError;

  static Future<CharacterSpec> loadOrCreate() async {
    try {
      final prefs = await SharedPreferences.getInstance()
          .timeout(const Duration(seconds: 5));
      var seed = prefs.getInt(_key);
      if (seed == null) {
        seed = math.Random().nextInt(1 << 30);
        await prefs.setInt(_key, seed);
      }
      return CharacterSpec.fromSeed(seed);
    } catch (e) {
      lastError = e.toString();
      return CharacterSpec.fromSeed(math.Random().nextInt(1 << 30));
    }
  }

  static Future<CharacterSpec> regenerate() async {
    final seed = math.Random().nextInt(1 << 30);
    try {
      final prefs = await SharedPreferences.getInstance()
          .timeout(const Duration(seconds: 5));
      await prefs.setInt(_key, seed);
    } catch (e) {
      lastError = e.toString();
    }
    return CharacterSpec.fromSeed(seed);
  }
}

/// Draws the character standing on [feet]. [height] is a nominal size: the
/// figure itself ends up roughly 0.85 * height tall.
void drawCharacter(
  Canvas canvas,
  CharacterSpec c, {
  required Offset feet,
  required double height,
  required double t,
  Emotion emotion = Emotion.neutral,
  Pose pose = Pose.idle,
  bool talking = false,
}) {
  final h = height;
  final ink = Paint()
    ..color = _inkColor
    ..style = PaintingStyle.stroke
    ..strokeWidth = h * 0.014
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;
  final fill = Paint()..style = PaintingStyle.fill;

  final x = feet.dx;
  final bob = math.sin(t * 2 * math.pi * 0.7) * h * 0.004;
  final walkPhase = t * 2 * math.pi * 1.6;
  final hip = Offset(x, feet.dy - h * 0.30 + bob);
  final shoulderY = hip.dy - h * 0.27;
  final headR = h * 0.115 * c.headScale;
  final neck = Offset(x, shoulderY);
  final headC = Offset(x, shoulderY - h * 0.02 - headR);

  // Legs
  for (final side in const [-1.0, 1.0]) {
    final swing = pose == Pose.walk
        ? math.sin(walkPhase + (side > 0 ? 0.0 : math.pi)) * 0.55
        : side * 0.07;
    final top = Offset(x + side * h * 0.035, hip.dy);
    final foot = Offset(
      top.dx + math.sin(swing) * h * 0.30,
      top.dy + math.cos(swing) * h * 0.30,
    );
    canvas.drawLine(top, foot, ink);
    final shoeDir = pose == Pose.walk ? 1.0 : side;
    canvas.drawLine(foot, Offset(foot.dx + shoeDir * h * 0.045, foot.dy), ink);
  }

  // Torso (shirt)
  final torso = RRect.fromLTRBR(
    x - h * 0.075,
    shoulderY,
    x + h * 0.075,
    hip.dy,
    Radius.circular(h * 0.04),
  );
  fill.color = c.outfit;
  canvas.drawRRect(torso, fill);
  canvas.drawRRect(torso, ink);

  // Arms
  final arms = _armAngles(pose, t);
  for (var i = 0; i < 2; i++) {
    final side = i == 0 ? -1.0 : 1.0;
    final a1 = arms[i][0];
    final a2 = arms[i][1];
    final shoulder = Offset(x + side * h * 0.075, shoulderY + h * 0.025);
    final elbow =
        shoulder + Offset(math.sin(a1) * side, math.cos(a1)) * (h * 0.15);
    final wrist = elbow +
        Offset(math.sin(a1 + a2) * side, math.cos(a1 + a2)) * (h * 0.15);
    canvas.drawLine(shoulder, elbow, ink);
    canvas.drawLine(elbow, wrist, ink);
    fill.color = Colors.white;
    canvas.drawCircle(wrist, h * 0.02, fill);
    canvas.drawCircle(wrist, h * 0.02, ink);
  }

  // Head, tilted around the neck
  double tilt;
  switch (emotion) {
    case Emotion.thinking:
      tilt = 0.12;
    case Emotion.sad:
      tilt = -0.10;
    case Emotion.worried:
      tilt = -0.05;
    case Emotion.happy:
      tilt = 0.03;
    case Emotion.neutral:
    case Emotion.surprised:
      tilt = 0.0;
  }
  tilt += math.sin(t * 1.3) * 0.015;
  if (pose == Pose.slump) tilt -= 0.08;

  canvas.save();
  canvas.translate(neck.dx, neck.dy);
  canvas.rotate(tilt);
  canvas.translate(-neck.dx, -neck.dy);

  canvas.drawLine(neck, Offset(neck.dx, headC.dy + headR), ink);
  fill.color = Colors.white;
  canvas.drawCircle(headC, headR, fill);
  canvas.drawCircle(headC, headR, ink);

  final eyes = _drawFace(canvas, c, headC, headR, t, emotion, talking, ink, fill);
  _drawHair(canvas, c, headC, headR, ink, fill);
  _drawAccessory(canvas, c, headC, headR, neck, h, eyes, ink, fill);

  canvas.restore();
}

List<List<double>> _armAngles(Pose pose, double t) {
  final sway = math.sin(t * 2 * math.pi * 0.7) * 0.04;
  switch (pose) {
    case Pose.idle:
      return [
        [0.18 + sway, 0.12],
        [0.18 - sway, 0.12],
      ];
    case Pose.pointUp:
      return [
        [0.18, 0.12],
        [2.55 + math.sin(t * 5) * 0.05, 0.1],
      ];
    case Pose.shrug:
      final shrugS = math.sin(t * 4) * 0.05;
      return [
        [0.85 + shrugS, 2.0],
        [0.85 - shrugS, 2.0],
      ];
    case Pose.wave:
      return [
        [0.18, 0.12],
        [2.2, math.sin(t * 9) * 0.45],
      ];
    case Pose.think:
      return [
        [0.18, 0.12],
        [0.15, -2.95],
      ];
    case Pose.walk:
      final walkS = math.sin(t * 2 * math.pi * 1.6);
      return [
        [0.1 + walkS * 0.5, 0.15],
        [0.1 - walkS * 0.5, 0.15],
      ];
    case Pose.slump:
      return [
        [0.05, 0.04],
        [0.05, 0.04],
      ];
  }
}

/// Draws eyes, brows and mouth. Returns the two eye centres (left, right).
List<Offset> _drawFace(
  Canvas canvas,
  CharacterSpec c,
  Offset hc,
  double r,
  double t,
  Emotion e,
  bool talking,
  Paint ink,
  Paint fill,
) {
  final blink = (t % 3.4) < 0.12;
  final eyeY = hc.dy - r * 0.05;
  final ex = r * 0.42;
  final k = e == Emotion.surprised ? 1.35 : 1.0;
  final look = e == Emotion.thinking ? Offset(r * 0.08, -r * 0.08) : Offset.zero;
  final centers = <Offset>[];

  for (final s in const [-1.0, 1.0]) {
    final p = Offset(hc.dx + s * ex, eyeY);
    centers.add(p);
    if (blink) {
      canvas.drawLine(p + Offset(-r * 0.12, 0), p + Offset(r * 0.12, 0), ink);
      continue;
    }
    if (c.eyeStyle == 1) {
      final rect = Rect.fromCenter(
        center: p,
        width: r * 0.34 * k,
        height: r * 0.46 * k,
      );
      fill.color = Colors.white;
      canvas.drawOval(rect, fill);
      canvas.drawOval(rect, ink);
      fill.color = _inkColor;
      canvas.drawCircle(p + look, r * 0.09 * k, fill);
    } else if (c.eyeStyle == 2) {
      fill.color = _inkColor;
      canvas.drawCircle(p + look, r * 0.15 * k, fill);
      fill.color = Colors.white;
      canvas.drawCircle(p + look + Offset(-r * 0.04, -r * 0.05), r * 0.045 * k, fill);
    } else {
      fill.color = _inkColor;
      canvas.drawCircle(p + look, r * 0.09 * k, fill);
    }
  }

  // Brows
  final browY = hc.dy - r * 0.40;
  final bw = r * 0.26;
  Offset b(double side, double dx, double dy) =>
      Offset(hc.dx + side * (ex + dx), browY + dy);
  for (final s in const [-1.0, 1.0]) {
    final path = Path();
    switch (e) {
      case Emotion.happy:
        path.moveTo(b(s, -bw, r * 0.02).dx, b(s, -bw, r * 0.02).dy);
        path.quadraticBezierTo(
          b(s, 0, -r * 0.12).dx, b(s, 0, -r * 0.12).dy,
          b(s, bw, r * 0.02).dx, b(s, bw, r * 0.02).dy,
        );
      case Emotion.surprised:
        path.moveTo(b(s, -bw, -r * 0.08).dx, b(s, -bw, -r * 0.08).dy);
        path.quadraticBezierTo(
          b(s, 0, -r * 0.26).dx, b(s, 0, -r * 0.26).dy,
          b(s, bw, -r * 0.08).dx, b(s, bw, -r * 0.08).dy,
        );
      case Emotion.worried:
      case Emotion.sad:
        path.moveTo(b(s, -bw, -r * 0.12).dx, b(s, -bw, -r * 0.12).dy);
        path.lineTo(b(s, bw, r * 0.05).dx, b(s, bw, r * 0.05).dy);
      case Emotion.thinking:
        if (s < 0) {
          path.moveTo(b(s, -bw, 0).dx, b(s, -bw, 0).dy);
          path.lineTo(b(s, bw, 0).dx, b(s, bw, 0).dy);
        } else {
          path.moveTo(b(s, -bw, -r * 0.08).dx, b(s, -bw, -r * 0.08).dy);
          path.quadraticBezierTo(
            b(s, 0, -r * 0.24).dx, b(s, 0, -r * 0.24).dy,
            b(s, bw, -r * 0.08).dx, b(s, bw, -r * 0.08).dy,
          );
        }
      case Emotion.neutral:
        path.moveTo(b(s, -bw, 0).dx, b(s, -bw, 0).dy);
        path.lineTo(b(s, bw, 0).dx, b(s, bw, 0).dy);
    }
    canvas.drawPath(path, ink);
  }

  // Mouth
  final my = hc.dy + r * 0.45;
  if (talking) {
    final open = 0.2 +
        0.8 * math.sin(t * 12).abs() * (0.6 + 0.4 * math.sin(t * 3.1).abs());
    final rect = Rect.fromCenter(
      center: Offset(hc.dx, my + r * 0.05),
      width: r * 0.5,
      height: r * 0.10 + r * 0.38 * open,
    );
    fill.color = const Color(0xFF4A1414);
    canvas.drawOval(rect, fill);
    canvas.drawOval(rect, ink);
  } else {
    final path = Path();
    switch (e) {
      case Emotion.happy:
        path.moveTo(hc.dx - r * 0.4, my - r * 0.05);
        path.quadraticBezierTo(hc.dx, my + r * 0.4, hc.dx + r * 0.4, my - r * 0.05);
      case Emotion.sad:
        path.moveTo(hc.dx - r * 0.3, my + r * 0.1);
        path.quadraticBezierTo(hc.dx, my - r * 0.2, hc.dx + r * 0.3, my + r * 0.1);
      case Emotion.worried:
        path.moveTo(hc.dx - r * 0.3, my);
        path.quadraticBezierTo(hc.dx - r * 0.15, my - r * 0.15, hc.dx, my);
        path.quadraticBezierTo(hc.dx + r * 0.15, my + r * 0.15, hc.dx + r * 0.3, my);
      case Emotion.surprised:
        final rect = Rect.fromCenter(
          center: Offset(hc.dx, my + r * 0.1),
          width: r * 0.25,
          height: r * 0.35,
        );
        path.addOval(rect);
      case Emotion.thinking:
        path.moveTo(hc.dx - r * 0.1, my);
        path.lineTo(hc.dx + r * 0.3, my - r * 0.1);
      case Emotion.neutral:
        path.moveTo(hc.dx - r * 0.25, my);
        path.lineTo(hc.dx + r * 0.25, my);
    }
    canvas.drawPath(path, ink);
  }

  return centers;
}

void _drawHair(
  Canvas canvas,
  CharacterSpec c,
  Offset hc,
  double r,
  Paint ink,
  Paint fill,
) {
  fill.color = c.hair;
  switch (c.hairStyle) {
    case 1:
      final spikePath = Path();
      const spikes = 5;
      final start = 1.08 * math.pi;
      final end = 1.92 * math.pi;
      for (var i = 0; i <= spikes * 2; i++) {
        final a = start + (end - start) * i / (spikes * 2);
        final rad = i.isEven ? r * 0.99 : r * 1.38;
        final p = Offset(hc.dx + math.cos(a) * rad, hc.dy + math.sin(a) * rad);
        if (i == 0) {
          spikePath.moveTo(p.dx, p.dy);
        } else {
          spikePath.lineTo(p.dx, p.dy);
        }
      }
      spikePath.lineTo(hc.dx + r * 0.55, hc.dy - r * 0.50);
      spikePath.lineTo(hc.dx, hc.dy - r * 0.42);
      spikePath.lineTo(hc.dx - r * 0.55, hc.dy - r * 0.50);
      spikePath.close();
      canvas.drawPath(spikePath, fill);
      canvas.drawPath(spikePath, ink);
    case 2:
      final bangRect = Rect.fromCircle(center: hc, radius: r * 1.02);
      final bangPath = Path()
        ..arcTo(bangRect, 1.05 * math.pi, 0.9 * math.pi, true);
      bangPath.quadraticBezierTo(
        hc.dx + r * 0.35, hc.dy - r * 0.62,
        hc.dx - r * 0.2, hc.dy - r * 0.50,
      );
      bangPath.quadraticBezierTo(
        hc.dx - r * 0.7, hc.dy - r * 0.40,
        hc.dx - r * 0.99, hc.dy - r * 0.156,
      );
      bangPath.close();
      canvas.drawPath(bangPath, fill);
      canvas.drawPath(bangPath, ink);
    case 3:
      for (var i = 0; i <= 6; i++) {
        final a = 1.1 * math.pi + 0.8 * math.pi * i / 6;
        final center = Offset(hc.dx + math.cos(a) * r, hc.dy + math.sin(a) * r);
        canvas.drawCircle(center, r * 0.27, fill);
        canvas.drawCircle(center, r * 0.27, ink);
      }
    case 4:
      fill.color = c.accent;
      final capRect = Rect.fromCircle(center: hc, radius: r * 1.04);
      final dome = Path()..arcTo(capRect, 1.12 * math.pi, 0.76 * math.pi, true);
      dome.close();
      canvas.drawPath(dome, fill);
      canvas.drawPath(dome, ink);
      final brim = RRect.fromLTRBR(
        hc.dx + r * 0.2,
        hc.dy - r * 0.46,
        hc.dx + r * 1.25,
        hc.dy - r * 0.30,
        Radius.circular(r * 0.08),
      );
      canvas.drawRRect(brim, fill);
      canvas.drawRRect(brim, ink);
    default:
      break;
  }
}

void _drawAccessory(
  Canvas canvas,
  CharacterSpec c,
  Offset hc,
  double r,
  Offset neck,
  double h,
  List<Offset> eyes,
  Paint ink,
  Paint fill,
) {
  switch (c.accessory) {
    case 1:
      final thin = Paint()
        ..color = _inkColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = ink.strokeWidth * 0.8;
      for (final p in eyes) {
        canvas.drawCircle(p, r * 0.28, thin);
      }
      canvas.drawLine(
        Offset(eyes[0].dx + r * 0.28, eyes[0].dy),
        Offset(eyes[1].dx - r * 0.28, eyes[1].dy),
        thin,
      );
    case 2:
      final scarf = RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(neck.dx, neck.dy + h * 0.005),
          width: h * 0.16,
          height: h * 0.04,
        ),
        Radius.circular(h * 0.02),
      );
      fill.color = c.accent;
      canvas.drawRRect(scarf, fill);
      canvas.drawRRect(scarf, ink);
    case 3:
      fill.color = c.accent;
      for (final side in const [-1.0, 1.0]) {
        final path = Path()
          ..moveTo(neck.dx, neck.dy + h * 0.012)
          ..lineTo(neck.dx + side * h * 0.05, neck.dy - h * 0.004)
          ..lineTo(neck.dx + side * h * 0.05, neck.dy + h * 0.028)
          ..close();
        canvas.drawPath(path, fill);
        canvas.drawPath(path, ink);
      }
    default:
      break;
  }
}

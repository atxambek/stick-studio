import 'llm_service.dart';
import 'models.dart';

class ScriptException implements Exception {
  ScriptException(this.message);
  final String message;

  @override
  String toString() => message;
}

class ScriptRequest {
  const ScriptRequest({
    required this.topic,
    required this.lang,
    this.facts = const [],
    this.topicId,
    this.factCount = 6,
  });

  final String topic;

  /// "en" or "uz"
  final String lang;

  /// Facts written by the user, one per entry. When empty, a built-in topic is used.
  final List<String> facts;
  final String? topicId;

  /// How many facts the AI model should write (3..12).
  final int factCount;
}

/// Anything that can turn a request into a list of scenes. The built-in engine
/// below works fully offline with templates. An on-device language model can be
/// plugged in later by implementing this same interface.
abstract class ScriptEngine {
  /// [onProgress] reports how many characters a language model has written so far.
  Future<List<VideoScene>> generate(
    ScriptRequest request, {
    void Function(int chars)? onProgress,
  });
}

// ---------------------------------------------------------------- topics

class TopicFact {
  const TopicFact(this.text, this.style);
  final String text;

  /// Index into the visual style table (mood, pose, background, prop).
  final int style;
}

class TopicText {
  const TopicText({
    required this.title,
    required this.hook,
    required this.facts,
    required this.twist,
  });

  final String title;
  final String hook;
  final List<TopicFact> facts;
  final String twist;
}

class TopicEntry {
  const TopicEntry({
    required this.id,
    required this.keywords,
    required this.en,
    required this.uz,
  });

  final String id;
  final List<String> keywords;
  final TopicText en;
  final TopicText uz;

  String titleFor(String lang) => lang == 'uz' ? uz.title : en.title;
  TopicText textFor(String lang) => lang == 'uz' ? uz : en;
}

const List<TopicEntry> kTopics = [
  TopicEntry(
    id: "sleep",
    keywords: ["sleep", "uxla", "uyqu"],
    en: TopicText(
      title: "Why do we sleep?",
      hook: "You will spend about one third of your life doing something that looks completely useless. "
          "You will lie there, unconscious, doing nothing. So why did evolution never get rid of it?",
      facts: [
        TopicFact(
            "In nineteen sixty four, a teenager named Randy Gardner stayed awake for eleven days, "
            "about two hundred sixty four hours, for a science fair project. By the end, he had trouble "
            "concentrating, and his memory and mood were falling apart.",
            0),
        TopicFact(
            "Researchers have found that after seventeen to nineteen hours awake, performance on some tasks "
            "drops to a level similar to having a small amount of alcohol in your blood.",
            2),
        TopicFact(
            "Studies in mice suggest the brain clears out waste products more efficiently during sleep, "
            "through a system scientists call the glymphatic system.",
            1),
        TopicFact(
            "During deep sleep, your brain also replays what you learned during the day, "
            "which helps move memories into long term storage.",
            5),
      ],
      twist: "The strangest part? Scientists still do not fully agree on the single main reason we sleep. "
          "It seems to do many jobs at once.",
    ),
    uz: TopicText(
      title: "Nega biz uxlaymiz?",
      hook: "Siz umringizning taxminan uchdan bir qismini tashqaridan qaraganda butunlay befoyda ishga sarflaysiz. "
          "Hushsiz yotasiz va hech narsa qilmaysiz. Xo'sh, nega evolyutsiya uyquni yo'qotib yubormadi?",
      facts: [
        TopicFact(
            "Ming to'qqiz yuz oltmish to'rtinchi yilda Rendi Gardner ismli o'smir fan ko'rgazmasi uchun "
            "o'n bir kun, ya'ni taxminan ikki yuz oltmish to'rt soat uxlamay turdi. Oxirida u diqqatini "
            "jamlay olmasdi, xotirasi va kayfiyati buzilib borardi.",
            0),
        TopicFact(
            "Tadqiqotchilar aniqlashicha, o'n yetti-o'n to'qqiz soat uyqusiz yurgandan keyin ba'zi "
            "topshiriqlardagi natija ozgina spirtli ichimlik ichgan odamnikiga yaqin darajaga tushadi.",
            2),
        TopicFact(
            "Sichqonlar ustidagi tadqiqotlar shuni ko'rsatadiki, uyqu paytida miya chiqindi moddalardan "
            "samaraliroq tozalanadi. Olimlar bu tizimni glimfatik tizim deb atashadi.",
            1),
        TopicFact(
            "Chuqur uyqu paytida miya kun davomida o'rgangan narsalaringizni qayta ishlaydi va "
            "xotirani uzoq muddatli saqlashga o'tkazishga yordam beradi.",
            5),
      ],
      twist: "Eng g'alatisi nima? Olimlar hanuzgacha uyquning yagona asosiy sababi haqida to'liq kelishmagan. "
          "Ko'rinishidan, uyqu bir vaqtning o'zida ko'p ishni bajaradi.",
    ),
  ),
  TopicEntry(
    id: "nocebo",
    keywords: ["nocebo", "placebo", "nosebo", "plasebo"],
    en: TopicText(
      title: "The evil placebo",
      hook: "You know the placebo effect: a fake pill that makes you feel better. "
          "But it has a darker twin, and it can make you feel worse, simply because you expect to.",
      facts: [
        TopicFact(
            "It is called the nocebo effect. When people expect side effects, they are more likely to feel them, "
            "even if the pill contains nothing active.",
            0),
        TopicFact(
            "In many clinical trials, people in the placebo group report side effects like headaches, nausea, "
            "and tiredness, even though they only took a sugar pill.",
            2),
        TopicFact(
            "Even the way a doctor describes a treatment can change what you feel. Warnings and negative wording "
            "can increase reported pain and side effects.",
            1),
        TopicFact(
            "This does not mean the symptoms are imaginary. Your brain really can produce pain and discomfort, "
            "because expectation changes how it processes signals from your body.",
            4),
      ],
      twist: "So your mind is not just watching your body. It is helping to write the story.",
    ),
    uz: TopicText(
      title: "Yomon plasebo",
      hook: "Siz plasebo effektini bilasiz: soxta tabletka sizni yaxshi his qildiradi. "
          "Lekin uning qorong'u egizagi ham bor. U sizni shunchaki yomonlikni kutganingiz uchun yomon his qildirishi mumkin.",
      facts: [
        TopicFact(
            "Uni nosebo effekti deyishadi. Odamlar nojo'ya ta'sirlarni kutsa, tarkibida faol modda bo'lmasa ham, "
            "ularni his qilish ehtimoli oshadi.",
            0),
        TopicFact(
            "Ko'pgina klinik sinovlarda plasebo guruhidagi odamlar faqat shakar tabletka ichgan bo'lsa ham, "
            "bosh og'rig'i, ko'ngil aynishi va charchoqdan shikoyat qilishadi.",
            2),
        TopicFact(
            "Hatto shifokor davolanishni qanday tasvirlashi ham sezgilaringizni o'zgartirishi mumkin. "
            "Ogohlantirishlar va salbiy so'zlar og'riq va nojo'ya ta'sirlar haqidagi xabarlarni ko'paytirishi mumkin.",
            1),
        TopicFact(
            "Bu simptomlar xayoliy degani emas. Miyangiz haqiqatan ham og'riq va noqulaylik yarata oladi, "
            "chunki kutish tana signallarini qayta ishlash usulini o'zgartiradi.",
            4),
      ],
      twist: "Demak, ongingiz tanangizni shunchaki kuzatib turmaydi. U hikoyani yozishda ham qatnashadi.",
    ),
  ),
  TopicEntry(
    id: "procrastination",
    keywords: ["procrastinat", "delay", "kechiktir", "dangasa"],
    en: TopicText(
      title: "Why we procrastinate",
      hook: "You have a deadline. You know exactly what to do. And somehow you are cleaning your room instead. "
          "Are you lazy? Probably not.",
      facts: [
        TopicFact(
            "Many researchers now see procrastination less as a time management problem and more as an emotion "
            "management problem. We delay tasks that make us feel anxious, bored, or unsure.",
            1),
        TopicFact(
            "Your brain also prefers rewards now over rewards later. Scientists call this present bias, "
            "and it can make the future version of you feel like a stranger.",
            2),
        TopicFact(
            "Avoiding the task gives quick relief, and that relief teaches your brain to do it again. "
            "That is how the loop gets stronger.",
            5),
        TopicFact(
            "One practical trick is to shrink the task. Promise yourself just five minutes. "
            "Starting is usually the hardest part.",
            3),
      ],
      twist: "So the next time you delay something, ask a different question. "
          "Not, why am I lazy, but, what feeling am I trying to avoid?",
    ),
    uz: TopicText(
      title: "Nega kechiktiramiz?",
      hook: "Sizda muddat bor. Nima qilishni aniq bilasiz. Lekin negadir uning o'rniga xonangizni yig'ishtirayapsiz. "
          "Siz dangasamisiz? Ehtimol, yo'q.",
      facts: [
        TopicFact(
            "Ko'plab tadqiqotchilar endi kechiktirishni vaqtni boshqarish muammosi emas, balki hissiyotni "
            "boshqarish muammosi deb bilishadi. Biz bezovta, zerikarli yoki noaniq tuyuladigan ishlarni kechiktiramiz.",
            1),
        TopicFact(
            "Miyangiz hozirgi mukofotni keyingi mukofotdan afzal ko'radi. Olimlar buni hozirgi tomon og'ish deb "
            "atashadi. Shu sabab kelajakdagi o'zingiz begonadek tuyulishi mumkin.",
            2),
        TopicFact(
            "Vazifadan qochish tezkor yengillik beradi. Bu yengillik miyaga buni yana takrorlashni o'rgatadi. "
            "Aylana shunday kuchayadi.",
            5),
        TopicFact(
            "Foydali usullardan biri vazifani kichraytirish. O'zingizga atigi besh daqiqa va'da bering. "
            "Boshlash odatda eng qiyin qism bo'ladi.",
            3),
      ],
      twist: "Shuning uchun keyingi safar nimanidir kechiktirsangiz, boshqa savol bering. "
          "Nega men dangasaman emas, qaysi tuyg'udan qochayapman?",
    ),
  ),
  TopicEntry(
    id: "memory",
    keywords: ["memory", "memories", "remember", "xotira", "eslash"],
    en: TopicText(
      title: "Your memory lies",
      hook: "You probably think your memories are like videos, stored safely and played back exactly as they happened. "
          "That is not how it works. Not even close.",
      facts: [
        TopicFact(
            "Each time you remember something, your brain partly rebuilds it. "
            "The memory can be slightly changed before it is stored again.",
            1),
        TopicFact(
            "In the nineteen nineties, psychologist Elizabeth Loftus showed that people can be led to remember "
            "events that never happened, such as being lost in a shopping mall as a child.",
            0),
        TopicFact(
            "Even vivid, emotional memories can be wrong. People can feel completely sure and still be mistaken.",
            2),
        TopicFact(
            "Memory fades fast too. In eighteen eighty five, Hermann Ebbinghaus found that we forget a large part "
            "of new information within days unless we review it.",
            5),
      ],
      twist: "Which is why reviewing information at spaced intervals works so well. "
          "You are not just storing a memory, you are rebuilding it stronger.",
    ),
    uz: TopicText(
      title: "Xotirangiz aldaydi",
      hook: "Ehtimol, siz xotiralaringizni video kabi, xavfsiz saqlanadigan va aynan sodir bo'lgandek qayta ijro "
          "etiladigan narsa deb o'ylaysiz. Aslida bunday emas. Umuman bunday emas.",
      facts: [
        TopicFact(
            "Har safar nimanidir eslaganingizda, miyangiz uni qisman qayta quradi. "
            "Xotira qayta saqlanishidan oldin ozgina o'zgarishi mumkin.",
            1),
        TopicFact(
            "Ming to'qqiz yuz to'qsoninchi yillarda psixolog Elizabet Loftus odamlarni hech qachon bo'lmagan "
            "voqealarni eslashga olib kelish mumkinligini ko'rsatdi, masalan bolaligida savdo markazida adashib qolgani.",
            0),
        TopicFact(
            "Hatto yorqin va hissiy xotiralar ham noto'g'ri bo'lishi mumkin. "
            "Odamlar to'liq ishonchli his qilishi va baribir adashishi mumkin.",
            2),
        TopicFact(
            "Xotira tez so'nadi ham. Ming sakkiz yuz sakson beshinchi yilda Hermann Ebbinghaus yangi "
            "ma'lumotning katta qismini takrorlamasak, bir necha kun ichida unutishimizni aniqladi.",
            5),
      ],
      twist: "Shuning uchun ma'lumotni oraliq bilan takrorlash juda yaxshi ishlaydi. "
          "Siz xotirani shunchaki saqlamaysiz, uni kuchliroq qilib qayta qurasiz.",
    ),
  ),
  TopicEntry(
    id: "habits",
    keywords: ["habit", "odat"],
    en: TopicText(
      title: "The 21 day myth",
      hook: "You have probably heard that it takes twenty one days to build a habit. "
          "It sounds scientific. It is also not really true.",
      facts: [
        TopicFact(
            "The idea is often traced back to a plastic surgeon named Maxwell Maltz, who noticed that patients "
            "took about twenty one days to get used to their new appearance.",
            1),
        TopicFact(
            "In a study from University College London in two thousand nine, researchers followed people trying "
            "to build a new habit. On average, it took sixty six days.",
            2),
        TopicFact(
            "But the range was huge, from eighteen days to two hundred fifty four days, "
            "depending on the person and the habit.",
            0),
        TopicFact(
            "Missing a single day did not ruin the process. What mattered most was repeating the behavior "
            "in the same situation.",
            4),
      ],
      twist: "So forget the magic number. Be consistent, be patient, and make it easy to do again tomorrow.",
    ),
    uz: TopicText(
      title: "21 kunlik afsona",
      hook: "Ehtimol, odat shakllantirish uchun yigirma bir kun kerak, degan gapni eshitgansiz. "
          "Bu ilmiy eshitiladi. Lekin aslida unchalik to'g'ri emas.",
      facts: [
        TopicFact(
            "Bu g'oya ko'pincha plastik jarroh Maksvell Maltsga borib taqaladi. U bemorlar yangi tashqi "
            "ko'rinishiga o'rganishi uchun taxminan yigirma bir kun ketishini kuzatgan.",
            1),
        TopicFact(
            "Ikki ming to'qqizinchi yilda London universiteti kolleji yangi odat shakllantirmoqchi bo'lgan "
            "odamlarni kuzatdi. O'rtacha olib qaraganda, bu oltmish olti kun davom etdi.",
            2),
        TopicFact(
            "Lekin farq juda katta edi: odam va odatga qarab o'n sakkiz kundan ikki yuz ellik to'rt kungacha.",
            0),
        TopicFact(
            "Bir kunni o'tkazib yuborish jarayonni buzmadi. "
            "Eng muhimi, xatti-harakatni bir xil vaziyatda takrorlash edi.",
            4),
      ],
      twist: "Shuning uchun sehrli raqamni unuting. Barqaror bo'ling, sabr qiling va ertaga buni takrorlashni osonlashtiring.",
    ),
  ),
];

// --------------------------------------------------------------- engine

class _Style {
  const _Style(this.emotion, this.pose, this.backdrop, this.prop);
  final Emotion emotion;
  final Pose pose;
  final Backdrop backdrop;
  final Prop prop;
}

const List<_Style> _styles = [
  _Style(Emotion.surprised, Pose.pointUp, Backdrop.abstract, Prop.exclamation),
  _Style(Emotion.thinking, Pose.think, Backdrop.blackboard, Prop.questionMark),
  _Style(Emotion.worried, Pose.shrug, Backdrop.cave, Prop.clock),
  _Style(Emotion.happy, Pose.wave, Backdrop.outdoors, Prop.sun),
  _Style(Emotion.neutral, Pose.idle, Backdrop.room, Prop.lightbulb),
  _Style(Emotion.thinking, Pose.idle, Backdrop.night, Prop.brain),
  _Style(Emotion.sad, Pose.slump, Backdrop.night, Prop.moon),
  _Style(Emotion.surprised, Pose.walk, Backdrop.city, Prop.arrow),
];

const List<String> _connectorsEn = [
  "Here is where it gets interesting.",
  "Now, this next part is strange.",
  "But that is not even the weirdest part.",
  "And then there is this.",
  "Here is the thing most people miss.",
];

const List<String> _connectorsUz = [
  "Mana endi qiziq joyi boshlanadi.",
  "Keyingi qism yanada g'alati.",
  "Lekin eng g'alati joyi bu emas.",
  "Va endi bunga e'tibor bering.",
  "Ko'pchilik e'tibor bermaydigan narsa shu.",
];

/// Offline template based script writer. The wording is fixed, the topic
/// content comes either from the built-in topics or from facts the user types.
class TemplateScriptEngine implements ScriptEngine {
  static const int maxFacts = 15;

  @override
  Future<List<VideoScene>> generate(
    ScriptRequest r, {
    void Function(int chars)? onProgress,
  }) async {
    final uz = r.lang == 'uz';
    final String title;
    final String hook;
    final List<TopicFact> facts;
    final String twist;

    if (r.facts.isNotEmpty) {
      if (r.topic.trim().isEmpty) {
        throw ScriptException(
            uz ? "Mavzu nomini yozing." : "Please enter a topic name.");
      }
      final topic = r.topic.trim();
      title = topic;
      hook = uz
          ? "Keling, bu haqda gaplashamiz: $topic. Bu ko'ringanidan ancha qiziqroq."
          : "Let us talk about this: $topic. It is more interesting than it looks.";
      final used = r.facts.take(maxFacts).toList();
      facts = [for (var i = 0; i < used.length; i++) TopicFact(used[i], i)];
      twist = uz
          ? "Va bularning hammasi kundalik hayotingizga ham tegishli."
          : "And all of this quietly affects your everyday life.";
    } else {
      final entry = _find(r);
      if (entry == null) {
        throw ScriptException(uz
            ? "Tayyor mavzulardan birini tanlang yoki o'z faktlaringizni yozing."
            : "Pick one of the ready topics or write your own facts.");
      }
      final text = entry.textFor(r.lang);
      title = text.title;
      hook = text.hook;
      facts = text.facts;
      twist = text.twist;
    }

    return assembleScenes(
      uz: uz,
      title: title,
      hook: hook,
      facts: facts,
      twist: twist,
    );
  }

  TopicEntry? _find(ScriptRequest r) {
    if (r.topicId != null) {
      for (final t in kTopics) {
        if (t.id == r.topicId) return t;
      }
    }
    final q = r.topic.toLowerCase();
    if (q.trim().isEmpty) return null;
    for (final t in kTopics) {
      for (final k in t.keywords) {
        if (q.contains(k)) return t;
      }
    }
    return null;
  }
}

/// Turns the pieces of a script into scenes: hook, facts with linking
/// phrases, a twist, a conclusion and an outro. Shared by every engine.
List<VideoScene> assembleScenes({
  required bool uz,
  required String title,
  required String hook,
  required List<TopicFact> facts,
  required String twist,
}) {
  final connectors = uz ? _connectorsUz : _connectorsEn;
  final scenes = <VideoScene>[
    VideoScene(
      narration: hook,
      bigText: title,
      emotion: Emotion.surprised,
      pose: Pose.pointUp,
      backdrop: Backdrop.abstract,
      prop: Prop.questionMark,
    ),
  ];

  for (var i = 0; i < facts.length; i++) {
    final st = _styles[facts[i].style % _styles.length];
    final lead = i == 0 ? "" : "${connectors[(i - 1) % connectors.length]} ";
    scenes.add(VideoScene(
      narration: lead + facts[i].text,
      emotion: st.emotion,
      pose: st.pose,
      backdrop: st.backdrop,
      prop: st.prop,
    ));
  }

  scenes.add(VideoScene(
    narration: twist,
    emotion: Emotion.thinking,
    pose: Pose.think,
    backdrop: Backdrop.night,
    prop: Prop.lightbulb,
  ));
  scenes.add(VideoScene(
    narration: uz
        ? "Demak, keyingi safar bu mavzu esingizga tushsa, unga biroz boshqacha qaraysiz."
        : "So the next time this comes up, you will see it a little differently.",
    emotion: Emotion.happy,
    pose: Pose.idle,
    backdrop: Backdrop.room,
    prop: Prop.heart,
  ));
  scenes.add(VideoScene(
    narration: uz
        ? "Agar bu sizni o'ylantirgan bo'lsa, obuna bo'ling. Keyingi videoda ko'rishamiz."
        : "If this made you think, subscribe, and I will see you in the next one.",
    emotion: Emotion.happy,
    pose: Pose.wave,
    backdrop: Backdrop.outdoors,
    prop: Prop.sun,
  ));
  return scenes;
}


// ------------------------------------------------------------- AI engine

class ParsedScript {
  const ParsedScript({
    required this.title,
    required this.hook,
    required this.facts,
    required this.twist,
  });

  final String title;
  final String hook;
  final List<String> facts;
  final String twist;
}

final RegExp _labelLine = RegExp(
  r'^\s*(?:[-•]\s*)?(?:\d+[.)]\s*)?(TITLE|HOOK|FACT|TWIST)\s*\d*\s*[:\-]\s*(.+)$',
  caseSensitive: false,
);

/// Reads the labelled lines (TITLE / HOOK / FACT / TWIST) the model was asked
/// to write. Tolerates markdown bold, bullets and numbering. Returns null when
/// nothing usable was found.
ParsedScript? parseLlmScript(String raw) {
  var title = '';
  var hook = '';
  var twist = '';
  final facts = <String>[];

  for (final line in raw.split('\n')) {
    final cleaned = line.replaceAll(RegExp(r'[*`#]'), '').trim();
    final m = _labelLine.firstMatch(cleaned);
    if (m == null) continue;
    final text = m.group(2)!.trim();
    if (text.length < 3) continue;
    switch (m.group(1)!.toUpperCase()) {
      case 'TITLE':
        title = text;
      case 'HOOK':
        hook = text;
      case 'FACT':
        if (text.length >= 20) facts.add(text);
      case 'TWIST':
        twist = text;
    }
  }

  if (hook.isEmpty || facts.isEmpty) return null;
  return ParsedScript(title: title, hook: hook, facts: facts, twist: twist);
}

/// Writes a fresh script about any topic with the on-device language model.
class LlmScriptEngine implements ScriptEngine {
  static const String _system =
      'You write narration scripts for short YouTube explainer videos. The narrator is calm, curious '
      'and speaks in simple, vivid words. Use only well established facts. If you are not sure about '
      'a number, a date or a name, leave it out. Never invent studies, experts or quotes.';

  @override
  Future<List<VideoScene>> generate(
    ScriptRequest r, {
    void Function(int chars)? onProgress,
  }) async {
    final uz = r.lang == 'uz';
    final topic = r.topic.trim();
    if (topic.isEmpty) {
      throw ScriptException(uz ? "Mavzuni yozing." : "Please enter a topic.");
    }
    if (!LlmService.isInstalled) {
      throw ScriptException(uz
          ? "AI model hali yuklab olinmagan."
          : "The AI model is not installed yet.");
    }

    final count = r.factCount.clamp(3, 12).toInt();
    final String raw;
    try {
      raw = await LlmService.generate(
        system: _system,
        prompt: _prompt(topic, r.lang, count),
        onProgress: onProgress,
      );
    } catch (e) {
      throw ScriptException(
          (uz ? "Model ishlamadi: " : "The model failed: ") + e.toString());
    }

    final parsed = parseLlmScript(raw);
    if (parsed == null || parsed.facts.length < 2) {
      throw ScriptException(uz
          ? "Model javobi tushunarsiz chiqdi. Qayta urinib ko'ring."
          : "The model's answer could not be understood. Please try again.");
    }

    return assembleScenes(
      uz: uz,
      title: parsed.title.isEmpty ? topic : parsed.title,
      hook: parsed.hook,
      facts: [
        for (var i = 0; i < parsed.facts.length; i++)
          TopicFact(parsed.facts[i], i),
      ],
      twist: parsed.twist.isEmpty
          ? (uz
              ? "Va bularning hammasi kundalik hayotingizga ham tegishli."
              : "And all of this quietly affects your everyday life.")
          : parsed.twist,
    );
  }

  String _prompt(String topic, String lang, int count) {
    final language = lang == 'uz'
        ? 'Uzbek, written in the Latin alphabet (for example "o\'zbek", "g\'alati")'
        : 'English';
    return 'Write a narration script about: $topic\n'
        'Language: $language\n\n'
        'Rules:\n'
        '- Spoken style with short, clear sentences. This text will be read aloud by a voice.\n'
        '- Write every number as words, no digits, no abbreviations, no emojis.\n'
        '- Each FACT is a different, true and interesting point, two or three sentences long.\n\n'
        'Reply with exactly these labelled lines and nothing else. Every label and its text must be '
        'on one single line:\n'
        'TITLE: two to five catchy words\n'
        'HOOK: two or three sentences that make the viewer curious\n'
        'FACT: ...   (write this line $count times, one new fact each time)\n'
        'TWIST: two sentences with a surprising closing thought\n';
  }
}

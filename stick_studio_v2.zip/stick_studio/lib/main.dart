import 'package:flutter/material.dart';

import 'home_page.dart';
import 'llm_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LlmService.init();
  runApp(const StickStudioApp());
}

class StickStudioApp extends StatelessWidget {
  const StickStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Stick Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB71C1C),
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

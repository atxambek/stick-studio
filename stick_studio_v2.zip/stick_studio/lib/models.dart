import 'dart:math' as math;

enum Emotion { neutral, happy, surprised, worried, sad, thinking }

enum Pose { idle, pointUp, shrug, wave, think, walk, slump }

enum Backdrop { room, outdoors, night, abstract, cave, blackboard, city }

enum Prop {
  none,
  questionMark,
  lightbulb,
  clock,
  brain,
  exclamation,
  arrow,
  sun,
  moon,
  zzz,
  heart,
}

/// One shot of the video: what the narrator says and what is on screen.
class VideoScene {
  VideoScene({
    required this.narration,
    this.bigText,
    this.emotion = Emotion.neutral,
    this.pose = Pose.idle,
    this.backdrop = Backdrop.room,
    this.prop = Prop.none,
  }) {
    reestimate();
  }

  String narration;

  /// Large thumbnail-style caption shown at the top (usually only the first scene).
  String? bigText;
  Emotion emotion;
  Pose pose;
  Backdrop backdrop;
  Prop prop;

  /// Seconds of speech. Replaced by the real value after text-to-speech runs.
  double speechDuration = 0;

  /// Total seconds the scene stays on screen (speech plus a short pause).
  double duration = 0;

  void reestimate() {
    speechDuration = estimateSpeech(narration);
    duration = speechDuration + 0.6;
  }

  static double estimateSpeech(String text) {
    final words =
        text.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;
    return math.max(1.0, words * 0.4);
  }
}

import 'dart:math' as math;
import 'dart:typed_data';

/// Mono 16-bit PCM audio.
class PcmAudio {
  PcmAudio(this.sampleRate, this.samples);

  final int sampleRate;
  final Int16List samples;

  double get seconds => samples.length / sampleRate;
}

/// Reads a RIFF/WAVE file and returns mono 16-bit samples.
/// Handles 8/16-bit integer and 32-bit float PCM, and streaming files whose
/// data chunk size is zero or unknown.
PcmAudio parseWav(Uint8List bytes) {
  if (bytes.length < 44) {
    throw const FormatException('WAV file is too short');
  }
  final bd = ByteData.sublistView(bytes);
  String tag(int o) => String.fromCharCodes(bytes.sublist(o, o + 4));
  if (tag(0) != 'RIFF' || tag(8) != 'WAVE') {
    throw const FormatException('The voice engine did not produce a WAV file');
  }

  var fmt = 1;
  var channels = 1;
  var rate = 22050;
  var bits = 16;
  var dataStart = -1;
  var dataLen = 0;

  var off = 12;
  while (off + 8 <= bytes.length) {
    final id = tag(off);
    var size = bd.getUint32(off + 4, Endian.little);
    final body = off + 8;
    if (id == 'fmt ') {
      fmt = bd.getUint16(body, Endian.little);
      channels = bd.getUint16(body + 2, Endian.little);
      rate = bd.getUint32(body + 4, Endian.little);
      bits = bd.getUint16(body + 14, Endian.little);
    } else if (id == 'data') {
      if (size == 0 || size == 0xFFFFFFFF || body + size > bytes.length) {
        size = bytes.length - body;
      }
      dataStart = body;
      dataLen = size;
      break;
    }
    off = body + size + (size & 1);
  }

  if (dataStart < 0) throw const FormatException('WAV has no audio data');
  if (channels < 1) throw const FormatException('WAV has no channels');

  final isInt16 = bits == 16 && (fmt == 1 || fmt == 0xFFFE);
  final isFloat32 = bits == 32 && fmt == 3;
  final isUint8 = bits == 8 && fmt == 1;
  if (!isInt16 && !isFloat32 && !isUint8) {
    throw FormatException('Unsupported WAV format (format $fmt, $bits bit)');
  }

  final bytesPerSample = bits ~/ 8;
  final frameBytes = bytesPerSample * channels;
  final frames = dataLen ~/ frameBytes;
  final out = Int16List(frames);

  for (var i = 0; i < frames; i++) {
    var acc = 0.0;
    for (var c = 0; c < channels; c++) {
      final p = dataStart + i * frameBytes + c * bytesPerSample;
      if (isInt16) {
        acc += bd.getInt16(p, Endian.little);
      } else if (isFloat32) {
        acc += bd.getFloat32(p, Endian.little) * 32767.0;
      } else {
        acc += (bd.getUint8(p) - 128) * 256.0;
      }
    }
    out[i] = (acc / channels).round().clamp(-32768, 32767).toInt();
  }
  return PcmAudio(rate, out);
}

/// Linear resampling. Good enough for speech.
Int16List resampleLinear(Int16List src, int from, int to) {
  if (from == to || src.isEmpty) return src;
  final n = (src.length * to / from).round();
  final out = Int16List(n);
  final ratio = from / to;
  for (var i = 0; i < n; i++) {
    final pos = i * ratio;
    final i0 = math.min(pos.floor(), src.length - 1);
    final i1 = math.min(i0 + 1, src.length - 1);
    final f = pos - i0;
    out[i] = (src[i0] * (1 - f) + src[i1] * f).round();
  }
  return out;
}

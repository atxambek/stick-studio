import 'dart:io';

import 'package:flutter_tts/flutter_tts.dart';

/// Thin wrapper around the phone's own text-to-speech engine (works offline
/// once the voice for the language is installed).
class TtsService {
  final FlutterTts _tts = FlutterTts();

  String localeFor(String lang) => lang == 'uz' ? 'uz-UZ' : 'en-US';

  /// Returns false when the phone has no voice for the language.
  Future<bool> prepare(String lang) async {
    final locale = localeFor(lang);
    final available = await _tts.isLanguageAvailable(locale);
    final ok = available == true || available == 1;
    if (!ok) return false;
    await _tts.setLanguage(locale);
    await _tts.setSpeechRate(0.45);
    await _tts.setPitch(1.0);
    await _tts.awaitSpeakCompletion(true);
    await _tts.awaitSynthCompletion(true);
    return true;
  }

  Future<void> speak(String text) async {
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
  }

  /// Writes the spoken [text] to a WAV file at [path].
  Future<void> synthesizeToWav(String text, String path) async {
    final file = File(path);
    if (await file.exists()) await file.delete();

    await _tts.synthesizeToFile(text, path, true);

    // Wait until the file exists and has stopped growing.
    var lastSize = -1;
    for (var i = 0; i < 100; i++) {
      if (await file.exists()) {
        final size = await file.length();
        if (size > 44 && size == lastSize) return;
        lastSize = size;
      }
      await Future<void>.delayed(const Duration(milliseconds: 150));
    }
    throw Exception('The voice file was not created');
  }
}

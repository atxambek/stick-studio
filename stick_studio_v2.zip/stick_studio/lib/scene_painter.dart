import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'character.dart';
import 'models.dart';

const Color _ink = Color(0xFF141414);

/// Draws one frame of a [VideoScene] at time [t] (seconds). The same painter is
/// used for the live preview and for rendering the exported video frames.
class ScenePainter extends CustomPainter {
  ScenePainter({
    required this.scene,
    required this.t,
    required this.character,
  });

  final VideoScene scene;
  final double t;
  final CharacterSpec character;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final ground = h * 0.84;

    canvas.save();
    canvas.clipRect(Offset.zero & size);

    _drawBackdrop(canvas, size, scene.backdrop, t);

    final hasProp = scene.prop != Prop.none;
    var cx = hasProp ? w * 0.32 : w * 0.5;
    if (scene.pose == Pose.walk) {
      final p = (t / math.max(0.5, scene.duration)).clamp(0.0, 1.0).toDouble();
      cx = w * (0.2 + 0.6 * p);
    }

    // Soft shadow under the feet
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(cx, ground + h * 0.012),
        width: h * 0.30,
        height: h * 0.03,
      ),
      Paint()..color = const Color(0x33000000),
    );

    final talking = t >= 0.1 && t < scene.speechDuration + 0.1;
    drawCharacter(
      canvas,
      character,
      feet: Offset(cx, ground),
      height: scene.bigText != null ? h * 0.68 : h * 0.78,
      t: t,
      emotion: scene.emotion,
      pose: scene.pose,
      talking: talking,
    );

    if (hasProp) {
      _drawProp(canvas, scene.prop, Offset(w * 0.74, h * 0.46), h * 0.14, t);
    }

    final big = scene.bigText;
    if (big != null && big.isNotEmpty) {
      _drawBigText(canvas, size, big, t);
    }

    _drawSubtitle(canvas, size, scene, t);

    // Fade in from black at the start of every scene
    final fade = (1 - t / 0.25).clamp(0.0, 1.0).toDouble();
    if (fade > 0) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = Color.fromRGBO(0, 0, 0, fade),
      );
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(ScenePainter old) =>
      old.t != t || old.scene != scene || old.character != character;
}

// ---------------------------------------------------------------- helpers

Paint _grad(Rect r, Color a, Color b) => Paint()
  ..shader = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [a, b],
  ).createShader(r);

void _text(
  Canvas canvas,
  String text,
  Offset center,
  double fontSize,
  Color color, {
  Color? outline,
  double outlineWidth = 0,
  double? maxWidth,
  int maxLines = 1,
  FontWeight weight = FontWeight.w900,
}) {
  TextPainter build(Paint? foreground) {
    return TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: weight,
          height: 1.05,
          color: foreground == null ? color : null,
          foreground: foreground,
        ),
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
      maxLines: maxLines,
    )..layout(maxWidth: maxWidth ?? double.infinity);
  }

  if (outline != null && outlineWidth > 0) {
    final o = build(
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = outlineWidth
        ..strokeJoin = StrokeJoin.round
        ..color = outline,
    );
    o.paint(canvas, center - Offset(o.width / 2, o.height / 2));
  }
  final f = build(null);
  f.paint(canvas, center - Offset(f.width / 2, f.height / 2));
}

// -------------------------------------------------------------- backdrops

void _drawBackdrop(Canvas canvas, Size s, Backdrop b, double t) {
  final w = s.width;
  final h = s.height;
  final ground = h * 0.84;
  final full = Offset.zero & s;
  final floorRect = Rect.fromLTWH(0, ground, w, h - ground);
  final line = Paint()
    ..color = _ink
    ..style = PaintingStyle.stroke
    ..strokeWidth = h * 0.006
    ..strokeCap = StrokeCap.round;

  switch (b) {
    case Backdrop.room:
      canvas.drawRect(full, Paint()..color = const Color(0xFFF0E2C0));
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFFC9A66B));
      final window = Rect.fromLTRB(w * 0.64, h * 0.14, w * 0.88, h * 0.52);
      canvas.drawRect(window, Paint()..color = const Color(0xFF9FD3F5));
      canvas.drawRect(window, line..strokeWidth = h * 0.012);
      canvas.drawLine(window.topCenter, window.bottomCenter, line);
      canvas.drawLine(window.centerLeft, window.centerRight, line);
      final frame = Rect.fromLTRB(w * 0.08, h * 0.18, w * 0.21, h * 0.40);
      canvas.drawRect(frame, Paint()..color = const Color(0xFFFFFFFF));
      final hill = Path()
        ..moveTo(frame.left, frame.bottom)
        ..lineTo(frame.left + frame.width * 0.4, frame.top + frame.height * 0.45)
        ..lineTo(frame.left + frame.width * 0.65, frame.top + frame.height * 0.7)
        ..lineTo(frame.left + frame.width * 0.8, frame.top + frame.height * 0.55)
        ..lineTo(frame.right, frame.bottom)
        ..close();
      canvas.drawPath(hill, Paint()..color = const Color(0xFF7CBF5A));
      canvas.drawRect(frame, line);
      canvas.drawLine(Offset(0, ground), Offset(w, ground), line);
    case Backdrop.outdoors:
      canvas.drawRect(full, _grad(full, const Color(0xFF8EC9F2), const Color(0xFFD8F0FF)));
      canvas.drawCircle(
        Offset(w * 0.86, h * 0.18),
        h * 0.075,
        Paint()..color = const Color(0xFFFFD43B),
      );
      canvas.drawOval(
        Rect.fromCenter(center: Offset(w * 0.25, ground + h * 0.05), width: w * 0.9, height: h * 0.5),
        Paint()..color = const Color(0xFF8FD16B),
      );
      canvas.drawOval(
        Rect.fromCenter(center: Offset(w * 0.85, ground + h * 0.08), width: w * 0.8, height: h * 0.45),
        Paint()..color = const Color(0xFF74BD52),
      );
      for (var i = 0; i < 3; i++) {
        final cxp = ((t * 0.02 + i * 0.37) % 1.2 - 0.1) * w;
        final cy = h * (0.14 + 0.09 * i);
        final cp = Paint()..color = const Color(0xCCFFFFFF);
        canvas.drawCircle(Offset(cxp, cy), h * 0.04, cp);
        canvas.drawCircle(Offset(cxp + h * 0.05, cy - h * 0.015), h * 0.05, cp);
        canvas.drawCircle(Offset(cxp + h * 0.11, cy), h * 0.04, cp);
      }
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFF7CBF5A));
    case Backdrop.night:
      canvas.drawRect(full, _grad(full, const Color(0xFF0B1030), const Color(0xFF27306B)));
      final starRnd = math.Random(7);
      for (var i = 0; i < 40; i++) {
        final sx = starRnd.nextDouble() * w;
        final sy = starRnd.nextDouble() * ground * 0.8;
        final tw = 0.5 + 0.5 * math.sin(t * 2 + i);
        canvas.drawCircle(
          Offset(sx, sy),
          h * (0.003 + 0.003 * starRnd.nextDouble()),
          Paint()..color = Color.fromRGBO(255, 255, 255, 0.35 + 0.6 * tw),
        );
      }
      canvas.drawCircle(
        Offset(w * 0.84, h * 0.2),
        h * 0.06,
        Paint()..color = const Color(0xFFFFF3B0),
      );
      canvas.drawOval(
        Rect.fromCenter(center: Offset(w * 0.3, ground + h * 0.06), width: w * 1.1, height: h * 0.4),
        Paint()..color = const Color(0xFF181D4A),
      );
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFF14183A));
    case Backdrop.abstract:
      canvas.drawRect(full, _grad(full, const Color(0xFF1B3A99), const Color(0xFF0B1E5C)));
      final c = Offset(w * 0.5, h * 0.45);
      for (var i = 0; i < 10; i++) {
        canvas.save();
        canvas.translate(c.dx, c.dy);
        canvas.rotate(t * 0.15 * (i.isEven ? 1 : -1) + i * 0.18);
        final side = h * (1.5 - i * 0.14);
        canvas.drawRect(
          Rect.fromCenter(center: Offset.zero, width: side, height: side),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = h * 0.012
            ..color = Color.fromRGBO(120, 170, 255, 0.25 + 0.03 * i),
        );
        canvas.restore();
      }
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFF0A1A4F));
    case Backdrop.cave:
      canvas.drawRect(full, _grad(full, const Color(0xFF2A1B12), const Color(0xFF4A3426)));
      final caveRnd = math.Random(3);
      var sx = 0.0;
      while (sx < w) {
        final sw = w * (0.05 + caveRnd.nextDouble() * 0.05);
        final sh = h * (0.08 + caveRnd.nextDouble() * 0.18);
        final spike = Path()
          ..moveTo(sx, 0)
          ..lineTo(sx + sw, 0)
          ..lineTo(sx + sw / 2, sh)
          ..close();
        canvas.drawPath(spike, Paint()..color = const Color(0xFF1A110B));
        sx += sw * 0.9;
      }
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFF241710));
    case Backdrop.blackboard:
      canvas.drawRect(full, Paint()..color = const Color(0xFF3B5E4B));
      final board = Rect.fromLTRB(w * 0.06, h * 0.08, w * 0.94, h * 0.70);
      canvas.drawRect(board, Paint()..color = const Color(0xFF1F3B2E));
      canvas.drawRect(
        board,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = h * 0.02
          ..color = const Color(0xFF8B5A2B),
      );
      final chalk = Paint()
        ..color = const Color(0x88FFFFFF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = h * 0.006
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset(w * 0.12, h * 0.2), Offset(w * 0.3, h * 0.2), chalk);
      canvas.drawLine(Offset(w * 0.12, h * 0.27), Offset(w * 0.24, h * 0.27), chalk);
      canvas.drawCircle(Offset(w * 0.86, h * 0.22), h * 0.05, chalk);
      canvas.drawLine(Offset(w * 0.8, h * 0.4), Offset(w * 0.9, h * 0.34), chalk);
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFFB78B5A));
    case Backdrop.city:
      canvas.drawRect(full, _grad(full, const Color(0xFFF6A55F), const Color(0xFF6C5B9E)));
      final cityRnd = math.Random(11);
      var bx = 0.0;
      while (bx < w) {
        final bw = w * (0.07 + cityRnd.nextDouble() * 0.06);
        final bh = h * (0.22 + cityRnd.nextDouble() * 0.30);
        canvas.drawRect(
          Rect.fromLTWH(bx, ground - bh, bw, bh),
          Paint()..color = const Color(0xFF2C2547),
        );
        for (var wy = ground - bh + h * 0.03; wy < ground - h * 0.04; wy += h * 0.05) {
          for (var wx = bx + bw * 0.15; wx < bx + bw * 0.8; wx += bw * 0.3) {
            if (cityRnd.nextDouble() > 0.45) {
              canvas.drawRect(
                Rect.fromLTWH(wx, wy, bw * 0.14, h * 0.025),
                Paint()..color = const Color(0xFFFFE08A),
              );
            }
          }
        }
        bx += bw * 1.02;
      }
      canvas.drawRect(floorRect, Paint()..color = const Color(0xFF3A3358));
  }
}

// ------------------------------------------------------------------ props

void _drawProp(Canvas canvas, Prop p, Offset c, double s, double t) {
  final ink = Paint()
    ..color = _ink
    ..style = PaintingStyle.stroke
    ..strokeWidth = s * 0.05
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;
  final fill = Paint()..style = PaintingStyle.fill;
  final pc = Offset(c.dx, c.dy + math.sin(t * 3) * s * 0.06);

  switch (p) {
    case Prop.none:
      return;
    case Prop.questionMark:
      _text(canvas, "?", pc, s * 1.9, const Color(0xFFFFD93B),
          outline: _ink, outlineWidth: s * 0.14);
    case Prop.exclamation:
      _text(canvas, "!", pc, s * 1.9, const Color(0xFFFF4D4D),
          outline: _ink, outlineWidth: s * 0.14);
    case Prop.lightbulb:
      final pulse = 0.5 + 0.5 * math.sin(t * 4);
      final ray = Paint()
        ..color = Color.fromRGBO(255, 224, 102, 0.4 + 0.5 * pulse)
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * 0.06
        ..strokeCap = StrokeCap.round;
      for (var i = 0; i < 8; i++) {
        final a = i * math.pi / 4;
        final d = Offset(math.cos(a), math.sin(a));
        canvas.drawLine(pc + d * (s * 0.75), pc + d * (s * (0.95 + 0.15 * pulse)), ray);
      }
      fill.color = const Color(0xFFFFE066);
      canvas.drawCircle(pc, s * 0.55, fill);
      canvas.drawCircle(pc, s * 0.55, ink);
      final base = RRect.fromRectAndRadius(
        Rect.fromCenter(center: pc + Offset(0, s * 0.72), width: s * 0.5, height: s * 0.3),
        Radius.circular(s * 0.06),
      );
      fill.color = const Color(0xFFB0B0B0);
      canvas.drawRRect(base, fill);
      canvas.drawRRect(base, ink);
    case Prop.clock:
      fill.color = Colors.white;
      canvas.drawCircle(pc, s * 0.7, fill);
      canvas.drawCircle(pc, s * 0.7, ink);
      for (var i = 0; i < 12; i++) {
        final a = i * math.pi / 6;
        final d = Offset(math.cos(a), math.sin(a));
        canvas.drawLine(pc + d * (s * 0.57), pc + d * (s * 0.64), ink);
      }
      final minute = t * 1.5 - math.pi / 2;
      final hour = t * 0.125 - math.pi / 2;
      canvas.drawLine(pc, pc + Offset(math.cos(minute), math.sin(minute)) * (s * 0.5), ink);
      canvas.drawLine(pc, pc + Offset(math.cos(hour), math.sin(hour)) * (s * 0.32), ink);
    case Prop.brain:
      fill.color = const Color(0xFFF4A6B8);
      final left = Rect.fromCenter(center: pc + Offset(-s * 0.25, 0), width: s * 0.95, height: s * 1.0);
      final right = Rect.fromCenter(center: pc + Offset(s * 0.25, 0), width: s * 0.95, height: s * 1.0);
      canvas.drawOval(left, fill);
      canvas.drawOval(right, fill);
      canvas.drawOval(left, ink);
      canvas.drawOval(right, ink);
      canvas.drawLine(pc + Offset(0, -s * 0.45), pc + Offset(0, s * 0.45), ink);
      for (final side in const [-1.0, 1.0]) {
        for (var i = -1; i <= 1; i++) {
          final y = pc.dy + i * s * 0.25;
          final x0 = pc.dx + side * s * 0.1;
          final squiggle = Path()
            ..moveTo(x0, y)
            ..quadraticBezierTo(x0 + side * s * 0.2, y - s * 0.12, x0 + side * s * 0.4, y);
          canvas.drawPath(squiggle, ink);
        }
      }
    case Prop.arrow:
      final a = Offset(pc.dx + math.sin(t * 5) * s * 0.12, pc.dy);
      final arrow = Path()
        ..moveTo(a.dx - s * 0.8, a.dy - s * 0.22)
        ..lineTo(a.dx + s * 0.1, a.dy - s * 0.22)
        ..lineTo(a.dx + s * 0.1, a.dy - s * 0.5)
        ..lineTo(a.dx + s * 0.8, a.dy)
        ..lineTo(a.dx + s * 0.1, a.dy + s * 0.5)
        ..lineTo(a.dx + s * 0.1, a.dy + s * 0.22)
        ..lineTo(a.dx - s * 0.8, a.dy + s * 0.22)
        ..close();
      fill.color = const Color(0xFFE53935);
      canvas.drawPath(arrow, fill);
      canvas.drawPath(arrow, ink);
    case Prop.sun:
      final rot = t * 0.6;
      final rayPaint = Paint()
        ..color = const Color(0xFFFFB300)
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * 0.07
        ..strokeCap = StrokeCap.round;
      for (var i = 0; i < 12; i++) {
        final a = rot + i * math.pi / 6;
        final d = Offset(math.cos(a), math.sin(a));
        canvas.drawLine(pc + d * (s * 0.68), pc + d * (s * 0.95), rayPaint);
      }
      fill.color = const Color(0xFFFFD43B);
      canvas.drawCircle(pc, s * 0.55, fill);
      canvas.drawCircle(pc, s * 0.55, ink);
    case Prop.moon:
      final whole = Path()..addOval(Rect.fromCircle(center: pc, radius: s * 0.6));
      final cut = Path()
        ..addOval(Rect.fromCircle(center: pc + Offset(s * 0.3, -s * 0.1), radius: s * 0.5));
      final moon = Path.combine(PathOperation.difference, whole, cut);
      fill.color = const Color(0xFFFFF0A8);
      canvas.drawPath(moon, fill);
      canvas.drawPath(moon, ink);
    case Prop.zzz:
      for (var i = 0; i < 3; i++) {
        final phase = (t * 0.6 + i / 3) % 1.0;
        final pos = pc + Offset(i * s * 0.35 + phase * s * 0.3, -phase * s * 1.0 + s * 0.4);
        _text(canvas, "Z", pos, s * (0.7 + 0.25 * i), Color.fromRGBO(255, 255, 255, 1 - phase),
            outline: Color.fromRGBO(20, 20, 20, 1 - phase), outlineWidth: s * 0.08);
      }
    case Prop.heart:
      final k = s * 0.9 * (1 + 0.08 * math.sin(t * 6));
      final heart = Path()
        ..moveTo(pc.dx, pc.dy + k * 0.55)
        ..cubicTo(pc.dx - k * 1.0, pc.dy - k * 0.05, pc.dx - k * 0.55, pc.dy - k * 0.75, pc.dx, pc.dy - k * 0.30)
        ..cubicTo(pc.dx + k * 0.55, pc.dy - k * 0.75, pc.dx + k * 1.0, pc.dy - k * 0.05, pc.dx, pc.dy + k * 0.55)
        ..close();
      fill.color = const Color(0xFFE53950);
      canvas.drawPath(heart, fill);
      canvas.drawPath(heart, ink);
  }
}

// ------------------------------------------------------------ text layers

void _drawBigText(Canvas canvas, Size size, String text, double t) {
  final w = size.width;
  final h = size.height;
  final k = (t / 0.35).clamp(0.0, 1.0).toDouble();
  final scale = 0.6 + 0.4 * Curves.easeOutBack.transform(k);
  final upper = text.toUpperCase();

  var fs = w * 0.095;
  while (fs > 20) {
    final probe = TextPainter(
      text: TextSpan(
        text: upper,
        style: TextStyle(fontSize: fs, fontWeight: FontWeight.w900, height: 1.05),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      maxLines: 2,
    )..layout(maxWidth: w * 0.9);
    if (!probe.didExceedMaxLines) break;
    fs *= 0.92;
  }

  canvas.save();
  final center = Offset(w * 0.5, h * 0.15);
  canvas.translate(center.dx, center.dy);
  canvas.scale(scale);
  canvas.translate(-center.dx, -center.dy);
  _text(
    canvas,
    upper,
    center,
    fs,
    const Color(0xFFFFE600),
    outline: _ink,
    outlineWidth: fs * 0.16,
    maxWidth: w * 0.9,
    maxLines: 2,
  );
  canvas.restore();
}

void _drawSubtitle(Canvas canvas, Size size, VideoScene scene, double t) {
  final words =
      scene.narration.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
  if (words.isEmpty) return;

  const perChunk = 6;
  final chunks = <String>[];
  for (var i = 0; i < words.length; i += perChunk) {
    chunks.add(words.sublist(i, math.min(i + perChunk, words.length)).join(' '));
  }
  final progress =
      (t / math.max(0.1, scene.speechDuration)).clamp(0.0, 0.999).toDouble();
  final index = (progress * chunks.length).floor().clamp(0, chunks.length - 1).toInt();

  final fs = size.height * 0.05;
  final tp = TextPainter(
    text: TextSpan(
      text: chunks[index],
      style: TextStyle(
        fontSize: fs,
        fontWeight: FontWeight.w700,
        color: Colors.white,
        height: 1.1,
      ),
    ),
    textDirection: TextDirection.ltr,
    textAlign: TextAlign.center,
    maxLines: 2,
  )..layout(maxWidth: size.width * 0.84);

  final center = Offset(size.width * 0.5, size.height * 0.925);
  final box = RRect.fromRectAndRadius(
    Rect.fromCenter(
      center: center,
      width: tp.width + size.height * 0.05,
      height: tp.height + size.height * 0.03,
    ),
    Radius.circular(size.height * 0.02),
  );
  canvas.drawRRect(box, Paint()..color = const Color(0x99000000));
  tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
}

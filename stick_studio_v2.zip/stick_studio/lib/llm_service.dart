import 'package:flutter_edge_ai/flutter_edge_ai.dart';
import 'package:flutter_edge_ai_litertlm/flutter_edge_ai_litertlm.dart';

/// On-device language model (Gemma 4 E2B, Apache-2.0, no account or token
/// needed). It is downloaded once from Hugging Face, then everything runs on
/// the phone with no internet.
class LlmService {
  static const String repo = 'litert-community/gemma-4-E2B-it-litert-lm';
  static const String sizeLabel = '2,6 GB';

  static bool _initialized = false;

  /// Set when the engine could not start (for example on an unsupported phone).
  static String? initError;

  static Future<void> init() async {
    try {
      await FlutterEdgeAi.initialize(
        inferenceEngines: const [LiteRtLmEngine()],
      ).timeout(const Duration(seconds: 20));
      _initialized = true;
    } catch (e) {
      initError = e.toString();
    }
  }

  static bool get isSupported => _initialized;

  static bool get isInstalled {
    if (!_initialized) return false;
    try {
      return FlutterEdgeAi.hasActiveModel();
    } catch (_) {
      return false;
    }
  }

  /// Downloads the model. [onProgress] receives 0..100.
  static Future<void> install(void Function(int percent) onProgress) async {
    if (!_initialized) {
      throw Exception(initError ?? 'The AI engine is not available');
    }
    await FlutterEdgeAi.installModel(
      modelType: ModelType.gemma4,
      fileType: ModelFileType.litertlm,
    ).fromHuggingFace(repo).withProgress(onProgress).install();
  }

  static Future<void> uninstall() async {
    final ids = await FlutterEdgeAi.listInstalledModels();
    for (final id in ids) {
      await FlutterEdgeAi.uninstallModel(id);
    }
    await FlutterEdgeAi.clearActiveInferenceIdentity();
  }

  /// Runs one prompt and returns the whole answer. The model is closed
  /// afterwards so its memory is free for voice and video rendering.
  static Future<String> generate({
    required String system,
    required String prompt,
    void Function(int chars)? onProgress,
  }) async {
    final model = await FlutterEdgeAi.getActiveModel(maxTokens: 4096);
    try {
      final chat = await model.createChat(systemInstruction: system);
      await chat.addQueryChunk(Message.text(text: prompt, isUser: true));
      final out = StringBuffer();
      await for (final response in chat.generateChatResponseAsync()) {
        if (response is TextResponse) {
          out.write(response.token);
          onProgress?.call(out.length);
        }
      }
      return out.toString();
    } finally {
      await model.close();
    }
  }
}
